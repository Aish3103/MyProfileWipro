export default function RenderInfo({ render }) {
  return <div>{render()}</div>;
}
