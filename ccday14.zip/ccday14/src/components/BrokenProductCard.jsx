export default function BrokenProductCard() {
  throw new Error("Product failed to load!");
}
